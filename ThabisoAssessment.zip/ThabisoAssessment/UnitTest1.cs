using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Internal;
using System;
using System.Collections.Generic;

namespace ThabisoAssessment
{
    [TestFixture]
    [Parallelizable]
    public class GetHeadlines
    {
        [Test]
        public void test1()
        {
            var driver = new ChromeDriver();
            driver.Navigate().GoToUrl("https://news.google.com/");
            driver.Manage().Window.Maximize();
            System.Threading.Thread.Sleep(2000);

            IList<IWebElement> searchText = driver.FindElements(By.TagName("h3"));
            foreach (IWebElement element in searchText)
            {
                Console.WriteLine(element.Text);
            }
            System.Threading.Thread.Sleep(6000);
            driver.Close();
         

        }

        [TestFixture]
        [Parallelizable]
        public class Register
        {
            [Test]
            public void test2()
            {
                var driver = new ChromeDriver();
                driver.Navigate().GoToUrl("https://www.hippodromeonline.com/");
                driver.Manage().Window.Maximize();
                System.Threading.Thread.Sleep(2000);
                System.Threading.Thread.Sleep(2000);
                driver.FindElement(By.ClassName("header-signInCta_register")).Click();
                driver.FindElement(By.Id("UserName")).SendKeys("ThabisoABCD");
                driver.FindElement(By.Id("Email")).SendKeys("thabisongwenyaa@gmail.com");
                driver.FindElement(By.Id("Password")).SendKeys("Thabiso11");
                driver.FindElement(By.Id("ConfirmPassword")).SendKeys("Thabiso11");
                driver.FindElement(By.ClassName("modal-button_next")).Click();
                driver.FindElement(By.Id("FirstName")).SendKeys("Thabiso");
                driver.FindElement(By.Id("LastName")).SendKeys("ngwenya");
                var selectElement = new SelectElement(driver.FindElement(By.Id("DateOfBirth_Day")));
                selectElement.SelectByText("02");
                var selectElement1 = new SelectElement(driver.FindElement(By.Id("DateOfBirth_Month")));
                selectElement1.SelectByText("06");
                var selectElement2 = new SelectElement(driver.FindElement(By.Id("DateOfBirth_Year")));
                selectElement2.SelectByText("2000");
                var selectElement3 = new SelectElement(driver.FindElement(By.Id("Gender")));
                selectElement3.SelectByText("Male");
                var selectElement4 = new SelectElement(driver.FindElement(By.Id("Language")));
                selectElement4.SelectByText("English");
                var selectElement5 = new SelectElement(driver.FindElement(By.Id("Currency")));
                selectElement5.SelectByText("British Pound");
                driver.FindElement(By.ClassName("modal-button_next")).Click();
                var selectElement6 = new SelectElement(driver.FindElement(By.Id("Currency")));
                selectElement6.SelectByText("Barbados");
                driver.FindElement(By.Id("ZipCode")).SendKeys("733");
                driver.FindElement(By.Id("Address1")).SendKeys("209 smit");
                driver.FindElement(By.Id("Address2")).SendKeys("209 smith");
                driver.FindElement(By.Id("City")).SendKeys("Johannesburg");
                var selectElement7 = new SelectElement(driver.FindElement(By.Id("Province")));
                selectElement7.SelectByText("Christ Church");
                driver.FindElement(By.Id("MobileTelephoneNumber")).SendKeys("46546464");
                var selectElement8 = new SelectElement(driver.FindElement(By.Id("dailyDepLimit")));
                selectElement8.SelectByText("20");
                var selectElement9 = new SelectElement(driver.FindElement(By.Id("weeklyDepLimit")));
                selectElement9.SelectByText("20");
                var selectElement10 = new SelectElement(driver.FindElement(By.Id("monthlyDepLimit")));
                selectElement10.SelectByText("20");
                driver.FindElement(By.Id("TermsAndConditionsAccepted_Label")).Click();
                driver.FindElement(By.Id("OptInSOB")).Click();
                driver.FindElement(By.ClassName("ReceiveCorrespondenceEmail")).Click();
                driver.FindElement(By.Id("register-submit-button"));
            
                driver.Close();


            }
        }

    }

    
}
